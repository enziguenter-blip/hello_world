# Proto-Disput im ChatGPT-Browser

Aktuelle Version: **0.1.2**. Die Versionsnummer wird oben im Scanner-Panel angezeigt.

Lokale Browser-Erweiterung für Windows 10, Firefox und Chrome. Sie bedient deinen bestehenden ChatGPT-Chat, verwendet dein angemeldetes Konto und **keine API**. Keine eigene Serverinstallation, keine Bibliotheken von fremden Servern, keine zusätzliche API-Abrechnung. Die normalen Beschränkungen deines ChatGPT-Tarifs bleiben bestehen.

**Stand: Prototyp, nicht an einem echten angemeldeten ChatGPT-Konto getestet.** Automatische Uploads und Downloads sind von der aktuellen Oberfläche abhängig. Ein vollständig unbeaufsichtigter Lauf wird noch nicht als verifiziert zugesichert. An einer simulierten Chatoberfläche werden Uploads, Antwortabschluss, Übergaben, Pausen und ZIP-Export getestet. Ergebnisse und Testumfang stehen in `TESTERGEBNISSE.md`.

## Installation unter Firefox (Testversion)

1. `dist/proto-disput-firefox.zip` herunterladen und in einen eigenen Ordner entpacken.
2. Firefox öffnen, `about:debugging#/runtime/this-firefox` in die Adresszeile eingeben.
3. **Temporäres Add-on laden** wählen und die entpackte `manifest.json` auswählen.
4. Einen normalen Chat auf `https://chatgpt.com` öffnen oder die Seite neu laden. Falls Firefox nach dem Zugriff auf diese Website fragt, diesen für die Erweiterung zulassen.
5. Unten rechts erscheint **Scanner-Ablauf**.

Ein temporäres Firefox-Add-on wird beim Beenden des Browsers entfernt. Danach muss es erneut geladen werden. Für eine dauerhafte reguläre Installation wäre eine Mozilla-Signierung erforderlich; diese Version ist nicht signiert. Vor dem Beenden Ergebnisse als ZIP sichern. Chrome bietet für diese lokale Testphase eine beständigere Installation.

## Installation unter Chrome

1. `dist/proto-disput-chrome.zip` herunterladen und entpacken.
2. `chrome://extensions` öffnen und **Entwicklermodus** einschalten.
3. **Entpackte Erweiterung laden** wählen und den Ordner mit der `manifest.json` auswählen.
4. ChatGPT öffnen oder neu laden. Unten rechts auf **Scanner-Ablauf** klicken.

## Einmal vorbereiten, dann eine Person wählen

1. Alle Quellen, Beispielbilder und Vorlagen lokal bereitlegen. Sie müssen jetzt nur auswählbar sein: Der Upload an ChatGPT erfolgt erst beim zugehörigen Schritt. Der Standardablauf enthält die **elf Schritte** aus deiner Prozessdatei.
2. Einen **neuen Chat** für diese Person und Auswertung öffnen. Das gewünschte Modell und gegebenenfalls dessen Denkmodus selbst in ChatGPT wählen. Eine vorhandene Auswertung nie parallel von zwei Tabs steuern.
3. Über **Quelldateien einmal auswählen** alle benötigten Dateien auswählen; alternativ einen Ordner auswählen. Bei Ordnerwahl keine unnötigen Dateien einbeziehen. Die Liste wird angezeigt.
4. **Dateien prüfen** anklicken. Die Standardkonfiguration verlangt die Originaldateinamen aus der Prozessbeschreibung. Abweichende Namen unter **Dateizuordnung und Prompts bearbeiten** anpassen. Doppelte Basenamen benötigen eindeutige relative Pfade inklusive ausgewähltem Hauptordner.
5. Zielperson eintragen. Die früher fest eingetragenen Zielnamen Marlies und Manuel werden in den Arbeitsaufträgen durch diese Person ersetzt. Namen in Beispiel-Dateinamen bleiben erhalten.
6. Beim ersten Einsatz **Nächsten Schritt testen** wählen. Prüfen, ob alle Anhänge angekommen sind, der Prompt genau einmal gesendet wurde und die Antwort vollständig ist. Upload bedeutet nicht, dass das LLM die Quelle vollständig verarbeitet hat.
7. Anschließend **Ablauf starten / fortsetzen**. Die Erweiterung arbeitet die verbleibenden Schritte ab, solange sie die Oberfläche und die Ergebnisse eindeutig erkennen kann. Tab und Browser geöffnet lassen, Ruhezustand vermeiden. Währenddessen nicht in andere Chats navigieren oder selbst weitere Nachrichten senden.
8. Abschließend **Ergebnisse als ZIP** herunterladen. Der Download erfolgt über diesen Knopf, damit der Browser ihn nicht als unerwünschten automatischen Download blockiert.

Die Konfiguration bleibt lokal gespeichert. Die Quelldateien werden nur für die laufende Seite im Arbeitsspeicher gehalten: Nach einem Neuladen müssen dieselben Dateien erneut ausgewählt werden. SHA-256-Prüfsummen verhindern das unbemerkte Fortsetzen mit anderen Quellinhalten. Für andere Gesprächsprotokolle und Vorlagen die Dateizuordnung aktualisieren und einen neuen Lauf anlegen.

## Aktualisierung von 0.1.0 / Eingabefeld nicht gefunden

Version 0.1.0 suchte ausschließlich nach `#prompt-textarea`. Meldet sie „ChatGPT-Eingabefeld nicht gefunden“, obwohl du einen normalen Chat geöffnet hast, kann die Feldkennung oder die gerenderte Editorvariante abweichen. Das ist kein Beleg, dass du auf der falschen Seite bist.

1. Das neue ZIP für deinen Browser von GitHub herunterladen und entpacken. Falls Chrome beim Download `(1)` an den ZIP-Dateinamen anhängt, ist das unproblematisch.
2. Die entpackten Erweiterungsdateien im **bisher verwendeten Erweiterungsordner** ersetzen. Nicht eine zweite Kopie der Erweiterung parallel installieren.
3. In Chrome `chrome://extensions` öffnen und auf der Karte **Proto-Disput · Browserablauf** den kreisförmigen **Neu laden**-Pfeil anklicken. Bei Firefox über `about:debugging#/runtime/this-firefox` das temporäre Add-on neu laden.
4. Den ursprünglichen ChatGPT-Tab mit F5 neu laden. Im Scanner-Panel muss **v0.1.2** stehen. Die Quelldateien erneut auswählen; der gespeicherte Lauf bleibt bei derselben Erweiterungsinstallation erhalten.
5. **Oberfläche prüfen** erkennt das Nachrichtenfeld, ohne etwas hochzuladen oder zu senden. Erkennt die Automatik es nicht eindeutig, **Chat-Eingabefeld auswählen** drücken und direkt in das normale Nachrichtenfeld von ChatGPT klicken. Das Scanner-Panel blendet sich während der Auswahl aus. Mit Esc lässt sich abbrechen. Die Zuordnung wird lokal gespeichert.
6. **Nächsten Schritt testen** anklicken. Ein Lauf mit 0/11 abgeschlossenen Schritten und ohne gesendeten Prompt kann bei Schritt 1 fortgesetzt werden. Es ist kein neuer Lauf nötig, solange Person und Quellen dieselben sind.

Seit Version 0.1.1 werden sichtbare Textareas, ProseMirror-/Lexical-Editoren, Nachrichtenfelder in bekannten Composer-Containern und verzögertes Laden unterstützt. Verborgene alte Felder und Editoren innerhalb vergangener Nachrichten werden ausgeschlossen. Bei mehreren gleichwertigen Kandidaten hält die Erweiterung an. Gespeicherte Standardselektoren aus 0.1.0 werden aktualisiert; eigene angepasste Selektoren bleiben erhalten.

Falls das Problem bleibt: **Oberfläche prüfen** anklicken und den angezeigten Diagnosetext kopieren. Er enthält Feldkennungen und Zustände, keine Nachrichten, Quelldateinamen oder Datei-/Gesprächsinhalte. Ein Screenshot oder der Gesprächsverlauf ist dafür nicht erforderlich. Die Erkennung ist weiterhin nicht gegen ein angemeldetes ChatGPT-Konto in dieser Cloud verifiziert.

## Prompt gesendet, aber nicht erkannt / fertige Antwort übernehmen

Die Meldung „Die gesendete Nachricht wurde nicht im Chat erkannt“ bedeutet nicht, dass ChatGPT die Arbeit abgebrochen hat. Die bisherige Minute betraf die Zuordnung des eigenen Nutzerprompts im sichtbaren Verlauf. Ein Scan von beispielsweise fünf Minuten darf weiterlaufen. Einen bereits gesendeten Prompt nicht manuell wiederholen und keinen neuen Lauf anlegen, nur weil die Erweiterung ihn nicht erkennt.

Version 0.1.2 erkennt weitere Nachrichtenkennungen und berücksichtigt bei der eindeutigen Schrittmarkierung auch ausgeblendeten Text, andere Zeilenumbrüche und Trennzeichen. Solange ein aktiver Generierungszustand erkannt wird, endet die Nachrichtensuche nicht wegen der bisherigen Minute. Bleibt die Zuordnung nach Ende der Generierung unmöglich, hält sie weiterhin an. Es werden keine Ergebnisse nach ihrer Position allein angenommen. Die Bindung an einen Chat, dessen Adresse erst nach dem ersten Senden entstand, kann mit einer eindeutig passenden Schrittmarkierung wiederhergestellt werden.

Für einen bereits angehaltenen Schritt mit fertiger Antwort:

1. Im ursprünglichen Chat bleiben und die fertige Antwort abwarten.
2. Version **0.1.2** installieren/neu laden wie oben beschrieben. Den Tab mit F5 neu laden und dieselben Quellen erneut auswählen. Der offene Schritt bleibt bei derselben Erweiterungsinstallation gespeichert.
3. **Vorhandene Antwort übernehmen** anklicken. Das Panel blendet sich aus. Direkt in den fertigen **Antworttext von ChatGPT** klicken, z. B. „OK. Alle sechs …“. Die angezeigte Zuordnung zu Person und Schritt prüfen und bestätigen.
4. Der Zähler steigt z. B. von **0/11 auf 1/11**. Der Bericht wird mit `manuallyAdopted: true` im Laufprotokoll gespeichert; dabei wird kein Prompt gesendet und kein Quelldokument erneut hochgeladen. Diese ausdrückliche Bestätigung ersetzt die automatische Nachrichtenzuordnung, nicht die fachliche Prüfung der Antwort. Erforderliche Original-Ergebnisdateien werden weiterhin geprüft.
5. **Ablauf starten / fortsetzen** beginnt beim nächsten Schritt. Alternativ lässt **Nächsten Schritt testen** nur den nächsten Schritt laufen.

Die Übernahme ist nur bei einem offenen Schritt verfügbar. Während ChatGPT noch generiert, wird sie abgewiesen. Ein Klick auf **Ablauf starten / fortsetzen** ohne manuelle Übernahme versucht zunächst, den offenen Schritt automatisch wiederzuerkennen; er sendet ihn nicht erneut. **Oberfläche prüfen** enthält jetzt zusätzlich Nachrichtenzähler und die Information, ob der offene Prompt erkannt wurde, ohne die Markierung oder die Nachrichtentexte auszugeben.

## Übergabe und Wiederverwendung von Ergebnissen

- Jede abgeschlossene Antwort wird als **Textabschrift in einer Markdown-Datei** gesichert. Die Abschrift ist keine originalgetreue Übernahme komplexer Formatierung und enthält keine verborgenen Gedankengänge. Sie ist nicht identisch mit einer möglicherweise zusätzlich vom LLM erzeugten PDF-/Word-Datei.
- `reuse` legt fest, welche früheren Textabschriften und gespeicherten Original-Ergebnisdateien erneut als Anhänge übergeben werden. Ein Download auf die Festplatte mit anschließendem Upload ist dafür nicht nötig. Der Chatverlauf bleibt zusätzlich im selben Chat erhalten.
- Sichtbare Grafiken und direkt lesbare Dateilinks innerhalb der Antwort versucht die Erweiterung als Originaldateien zu übernehmen. Es werden nur sichtbare URLs gelesen; keine internen API-Endpunkte geraten, keine Zugangsdaten extrahiert und keine Downloads in beliebigen Windows-Ordnern überwacht.
- **Grenze:** Manche ChatGPT-Dateilinks, insbesondere `sandbox:`-Links, können nur durch die Oberfläche aufgelöst werden. Bilddateien können ebenfalls durch Zugriffsbeschränkungen unlesbar sein. In diesem Fall pausiert der Ablauf. Datei regulär aus ChatGPT herunterladen, im Panel unter **Ergebnisdateien ergänzen** dem offenen Schritt zuordnen und fortsetzen. Diese manuelle Ersatz-Zuordnung wird im Laufprotokoll festgehalten.
- Die Infografik-Schritte 5 und 7 gelten erst mit einer erkannten oder ausdrücklich ergänzten Datei als abgeschlossen. Die Prüfung bestätigt das Vorhandensein einer Datei, nicht ihre fachliche oder grafische Qualität.
- Für Schritt 9 war keine separate Vorlage angegeben. Der entsprechende Prompt ist als Bearbeitungsvorschlag enthalten; ergänze eine Vorlage in `files`, wenn du eine hast.
- Das ZIP enthält die Textberichte, verfügbare Original-Ergebnisdateien und `lauf.json`. **Nicht enthalten:** die ursprünglichen Quelldateien. Fehlen nach einem Neuladen Binärdateien, werden sie im ZIP ausdrücklich als fehlend aufgelistet.

## Wann beginnt der nächste Schritt?

Es gibt keinen festen Timer für einen Scan. Die automatische Erkennung verlangt einen eindeutig markierten eigenen Nutzerprompt im Seiteninhalt, eine nachfolgende Assistentenantwort, ein erkanntes Abschluss-Bedienelement, keinen erkannten laufenden Generierungszustand und einen kurzzeitig stabilen Antwortinhalt. Für Bilder wird zusätzlich deren Ladezustand geprüft. Nachrichtensuche und Antwortprüfung haben jeweils eine Höchstgrenze von zwei Stunden. Diese Grenzen lösen keinen Folgeschritt aus. Uploads haben eine separate Grenze von drei Minuten. Bei ausdrücklich manuell übernommener Antwort bestätigt der Nutzer die Fertigstellung. Solche Oberflächensignale ersetzen keine offizielle Fertigstellungs-Schnittstelle und müssen im echten Chat erprobt werden.

Bei Pause kann ChatGPT weiterarbeiten; nur die Ablaufsteuerung wird unterbrochen. Beim Fortsetzen eines bereits gesendeten Schritts wird dessen Antwort gesucht, **nicht erneut gesendet**. Ist das Senden unklar, wird angehalten. Nicht ungeprüft einen neuen Lauf starten. Schlägt die Vorbereitung vor dem Senden fehl, müssen eventuell liegen gebliebene Anhänge und der vorbereitete Prompt zuerst aus dem Eingabefeld entfernt werden.

## Kontext und Dateien

**Ein einzelner Chat garantiert nicht, dass zwölf beziehungsweise elf lange Arbeitsschritte gleichzeitig vollständig im Modellkontext liegen.** Kontextgrenzen, Dateiverarbeitung und Komprimierung hängen von Modell, Tarif und ChatGPT ab. Die Erweiterung kann diese Grenzen nicht messen, vergrößern oder umgehen. Erneutes Anhängen wichtiger Ergebnisse macht die Übergaben explizit, garantiert aber ebenfalls kein vollständiges Einlesen. Sie prüft keine Behauptung des LLMs, es habe „100 % gelesen“, und prüft nicht automatisch die Einhaltung sämtlicher Fachvorlagen oder der 5.000-Zeichen-Vorgabe.

## Lokale Daten und Berechtigungen

Die Erweiterung läuft nur auf `https://chatgpt.com/*`. Sie speichert Fortschritt, Antworttexte und Konfiguration im lokalen Erweiterungsspeicher. Original-Quellinhalte und binäre Ergebnisdateien bleiben im Arbeitsspeicher bis zum Neuladen. Beim Ausführen gehen die gewählten Anhänge und Prompts an ChatGPT, entsprechend der dortigen Kontoeinstellungen. Es gibt keine zusätzlichen Analyse- oder Telemetriedienste. Lokal gespeicherte Berichte können personenbezogene Inhalte enthalten; ZIP-Dateien entsprechend aufbewahren. „Neuer Lauf“ ersetzt den zuletzt gespeicherten Lauf, ohne den Chat zu löschen. Die Deinstallation löscht den lokalen Erweiterungsspeicher.

## Entwicklung und Prüfen

Keine Paketinstallation zum Bauen nötig:

```sh
python tools/package.py
```

Für die isolierten Browserprüfungen werden Python, Playwright und Chromium benötigt. Das verändert den ChatGPT-Account nicht:

```sh
python tests/test_browser.py
```

Die Browsererweiterung enthält keine Hintergrundprozesse und keine Geheimnisse. `extension/manifest.json` ist für Firefox; der Paketbau erzeugt zusätzlich eine Chrome-Version ohne Firefox-spezifische Manifestfelder.
